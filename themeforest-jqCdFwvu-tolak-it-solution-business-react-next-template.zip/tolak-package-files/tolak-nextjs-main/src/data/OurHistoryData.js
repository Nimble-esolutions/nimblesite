const ourHistoryData = {
  tagline: "OUR COMPANY HISTORY",
  title: "Present Company History in PowerPoint",

  items: [
    {
      id: 1,

      text: "Projects company support team stands ready to our reliable or assistance of best and technical",
      title: "IT Consultant",
      date: "02-08-2021",
      year: "2021",
    },
    {
      id: 2,

      text: "Projects company support team stands ready to our reliable or assistance of best and technical",
      title: "Business Story",
      date: "02-08-2022",
      year: "2022",
    },
    {
      id: 3,

      text: "Projects company support team stands ready to our reliable or assistance of best and technical",
      title: "Solution Agency",
      date: "02-08-2023",
      year: "2023",
    },
    {
      id: 4,

      text: "Projects company support team stands ready to our reliable or assistance of best and technical",
      title: "Brand Strategy",
      date: "02-08-2024",
      year: "2024",
    },
  ],
};

export default ourHistoryData;
