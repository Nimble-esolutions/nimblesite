import bg1 from "@/assets/images/backgrounds/slider-4-1.jpg";
import bg2 from "@/assets/images/backgrounds/slider-4-2.jpg";

const mainSliderFourData = [
  {
    id: 1,
    bg: bg1,
    subTitle: "Wellcome To Tolak !",
    titleTwo: "We Marketing Process",
    title: "Solution Service !",
    text: "Business a soluion and emirate in the Arab known \n for luxury city for Company.",
  },
  {
    id: 2,
    bg: bg2,
    subTitle: "Wellcome To Tolak !",
    titleTwo: "We Marketing Process",
    title: "Solution Service !",
    text: "Business a soluion and emirate in the Arab known \n for luxury city for Company.",
  },
];
export default mainSliderFourData;
