import bg from "@/assets/images/resources/cta-5-bg.jpg";

const ctaFiveData = {
  bg,
  icon: "icon-customer-service",
  title: "Our Best It-Solution for",
  href: "contact",
};
export default ctaFiveData;
