import bg from '@/assets/images/backgrounds/video-bg-3.jpg'
const videoThreeData = {
    bg,
    videoId: "h9MbznbxlLc"
}
export default videoThreeData