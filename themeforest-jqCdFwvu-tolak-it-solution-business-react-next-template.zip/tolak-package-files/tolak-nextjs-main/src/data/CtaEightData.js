import bg from '@/assets/images/backgrounds/cta-8-bg.jpg'
import shape1 from '@/assets/images/shapes/cta-8-1.png'
import shape2 from '@/assets/images/shapes/cta-8-2.png'

const ctaEightData = {
    bg,
    shape1,
    shape2,

    title: "We Provide More Details Let Me Know Solution \n What You Need Help",
    text: "Technology is a broad category encompassing nformation \n technology and the application of technology.",

    href: "contact"




}
export default ctaEightData