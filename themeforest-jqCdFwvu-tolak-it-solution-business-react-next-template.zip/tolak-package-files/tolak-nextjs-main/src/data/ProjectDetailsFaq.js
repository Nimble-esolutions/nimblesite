import faqImage from "@/assets/images/resources/counter-1-1.jpg";

const projectDetailsFaqData = {
  accordionData: [
    {
      id: 1,
      title: "Maecenas facilisis erat id odio",
      content:
        "There are many variations of passages of is psum available, but the majority have suffered alteration in some we form, by injected humour,",
    },
    {
      id: 2,
      title: "Phasellus et vehicula nulla",
      content:
        "There are many variations of passages of is psum available, but the majority have suffered alteration in some we form, by injected humour,",
    },
    {
      id: 3,
      title: "Maecenas malesuada",
      content:
        "There are many variations of passages of is psum available, but the majority have suffered alteration in some we form, by injected humour,",
    },
    {
      id: 4,
      title: "Why you join our team",
      content:
        "There are many variations of passages of is psum available, but the majority have suffered alteration in some we form, by injected humour,",
    },
    {
      id: 5,
      title: "Maecenas malesuada",
      content:
        "There are many variations of passages of is psum available, but the majority have suffered alteration in some we form, by injected humour,",
    },
  ],
  image: faqImage,
  counter: {
    count: 34,
    label: "k+",
    text: "Customers Support",
  },
};

export default projectDetailsFaqData;
