

const funFactTwoData =
    [
        {
            id: 1,
            icon: "icon-briefing",
            text: "Completed Project",
            count: "426",

        },
        {
            id: 2,
            icon: "icon-ancestors",
            text: "Happy Clients",
            count: "1425",

        },
        {
            id: 3,
            icon: "icon-admin",
            text: "Business Partners",
            count: "750",

        },
        {
            id: 4,
            icon: "icon-trophy",
            text: "Award Win",
            count: "884",
        },
    ]

export default funFactTwoData;
