const featureTwoData = [
    {
        id: 1,
        icon: "icon-cooperation",
        title: "Business Of Growth",
        text: "We businesss standard chunk of Ipsum used since is Agency & Star tup.",
    },
    {
        id: 2,
        icon: "icon-ads-campaign",
        title: "We Grow Business",
        text: "We businesss standard chunk of Ipsum used since is Agency & Star tup.",
        identity: "feature-two__item--reverse"
    },
    {
        id: 3,
        icon: "icon-advertisig-agency",
        title: "Markting Solution",
        text: "We businesss standard chunk of Ipsum used since is Agency & Star tup.",
    }

]

export default featureTwoData;