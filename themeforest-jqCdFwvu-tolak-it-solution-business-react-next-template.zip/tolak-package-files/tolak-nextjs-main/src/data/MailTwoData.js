import bg from "@/assets/images/shapes/mail-bg.png";
const mailTwoData = {
  bg,
  icon: "icon-messages",
  title: "Subscribe To Our Newsletter",
  titleFive: "Subscribe Your News Latter Solutions?"
};
export default mailTwoData;
