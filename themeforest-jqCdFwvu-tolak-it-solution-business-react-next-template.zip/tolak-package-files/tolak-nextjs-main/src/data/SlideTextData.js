import bg from '@/assets/images/backgrounds/slide-text-bg.jpg'
const slideTextData = {
    bg,
    lists: [
        "Service",
        "Technology",
        "Business",
        "Consultancy",
        "Support",
        "Management",
        "Design",
        "Development",
        "Service",
        "Technology",
        "Business",
        "Consultancy",
        "Support",
        "Management",
        "Design",
        "Development"]
}
export default slideTextData;