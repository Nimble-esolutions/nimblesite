const featureFourData = [
  {
    id: 1,
    icon: "icon-agent",
    title: "Grow Technology",
  },
  {
    id: 2,
    icon: "icon-solutions",
    title: "Business Services",
  },
  {
    id: 3,
    icon: "icon-cooperation",
    title: "Project Complete",
  },
];

export default featureFourData;
